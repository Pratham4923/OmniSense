@echo off
title OmniSense Dashboard Launcher
echo ==========================================
echo    OmniSense Emergency Traffic System
echo    Initializing Dashboard...
echo ==========================================

:: Check if Python is installed
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python is not installed or not in PATH.
    pause
    exit /b
)

:: Install/Update dependencies
echo [1/2] Checking dependencies...
pip install -r frontend\requirements.txt --quiet

:: Launch the application
echo [2/2] Launching OmniSense Dashboard...
cd frontend
python app.py

pause
