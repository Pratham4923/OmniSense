import hashlib
import secrets
from datetime import datetime


RFID_HANDSHAKE_TIMINGS = {
    "tag_detected": 0.8,
    "challenge_issued": 1.6,
    "authenticated": 2.4,
    "priority_granted": 3.0,
}


RFID_REGISTRY = {
    "Ambulance": {
        "vehicle_id": "EMRG-AMB-911",
        "tag_uid": "TAG-7A91-C2",
        "reader_id": "BLR-RDR-ALPHA",
        "lane": "Northbound priority",
        "secret": "omnisense-ambulance-priority",
    },
    "Firetruck": {
        "vehicle_id": "EMRG-FIR-112",
        "tag_uid": "TAG-4F23-A8",
        "reader_id": "BLR-RDR-BRAVO",
        "lane": "Hazmat response lane",
        "secret": "omnisense-firetruck-priority",
    },
}


def event_time(now=None):
    timestamp = datetime.fromtimestamp(now)
    return timestamp.strftime("%H:%M:%S")


def expected_response(secret, challenge):
    digest = hashlib.sha256(f"{secret}:{challenge}".encode("utf-8")).hexdigest().upper()
    return digest[:12]


class RFIDHandshakeManager:
    def __init__(self):
        self.requested_vehicle_type = None
        self.session = None

    def reset(self):
        self.requested_vehicle_type = None
        self.session = None

    def start(self, vehicle_type, now):
        profile = RFID_REGISTRY[vehicle_type]
        challenge = secrets.token_hex(4).upper()
        response = expected_response(profile["secret"], challenge)

        self.requested_vehicle_type = vehicle_type
        self.session = {
            "vehicle_type": vehicle_type,
            "vehicle_id": profile["vehicle_id"],
            "tag_uid": profile["tag_uid"],
            "reader_id": profile["reader_id"],
            "lane": profile["lane"],
            "challenge": challenge,
            "response": response,
            "status": "tag_detected",
            "started_at": now,
            "last_transition_at": now,
            "expires_at": 0.0,
            "last_active": event_time(now),
            "audit": [
                {
                    "time": event_time(now),
                    "title": "Tag detected",
                    "detail": f"{profile['tag_uid']} entered {profile['reader_id']}",
                }
            ],
        }

    def add_audit_entry(self, now, title, detail):
        if not self.session:
            return

        audit = self.session.setdefault("audit", [])
        audit.insert(
            0,
            {
                "time": event_time(now),
                "title": title,
                "detail": detail,
            },
        )
        del audit[6:]
        self.session["last_active"] = event_time(now)
        self.session["last_transition_at"] = now

    def advance(self, now):
        if not self.session:
            return None

        emitted = {
            "priority_granted": False,
            "priority_expired": False,
            "vehicle_type": None,
            "expires_at": 0.0,
        }

        while True:
            elapsed = now - self.session["started_at"]
            current_status = self.session["status"]

            if current_status == "tag_detected" and elapsed >= RFID_HANDSHAKE_TIMINGS["tag_detected"]:
                self.session["status"] = "challenge_issued"
                self.add_audit_entry(
                    now,
                    "Reader challenge sent",
                    f"Nonce {self.session['challenge']} dispatched to {self.session['tag_uid']}",
                )
                continue

            if current_status == "challenge_issued" and elapsed >= RFID_HANDSHAKE_TIMINGS["challenge_issued"]:
                self.session["status"] = "authenticated"
                self.add_audit_entry(
                    now,
                    "Mutual auth passed",
                    f"Signed reply {self.session['response']} validated for {self.session['vehicle_id']}",
                )
                continue

            if current_status == "authenticated" and elapsed >= RFID_HANDSHAKE_TIMINGS["authenticated"]:
                self.session["status"] = "priority_granted"
                self.session["expires_at"] = now + 12
                emitted["priority_granted"] = True
                emitted["vehicle_type"] = self.session["vehicle_type"]
                emitted["expires_at"] = self.session["expires_at"]
                self.add_audit_entry(
                    now,
                    "Signal grant issued",
                    f"{self.session['lane']} opened at {self.session['reader_id']}",
                )
                continue

            if current_status == "priority_granted" and self.session["expires_at"] and now >= self.session["expires_at"]:
                self.session["status"] = "expired"
                emitted["priority_expired"] = True
                self.add_audit_entry(
                    now,
                    "Session expired",
                    f"Priority window closed for {self.session['vehicle_id']}",
                )
                continue

            if current_status == "expired" and elapsed >= RFID_HANDSHAKE_TIMINGS["priority_granted"] + 14:
                self.reset()

            break

        return emitted

    def build_payload(self, now):
        if not self.session:
            return {
                "vehicle_id": "NO-TAG",
                "authenticated": False,
                "type": "No emergency tag in range",
                "last_active": "N/A",
                "handshake_status": "idle",
                "challenge": None,
                "response_preview": None,
                "lane": "Standby corridor watch",
                "reader_id": "BLR-RDR-STANDBY",
                "tag_uid": None,
                "session_age_s": 0.0,
                "steps": [
                    {"label": "Tag detect", "state": "current", "detail": "Waiting for an RFID beacon"},
                    {"label": "Challenge", "state": "pending", "detail": "Reader nonce not issued"},
                    {"label": "Auth", "state": "pending", "detail": "Cryptographic check idle"},
                    {"label": "Grant", "state": "pending", "detail": "Signal corridor closed"},
                ],
                "audit_log": [
                    {
                        "time": event_time(now),
                        "title": "Idle reader",
                        "detail": "No authenticated emergency vehicle in range",
                    }
                ],
            }

        status_to_step = {
            "tag_detected": 0,
            "challenge_issued": 1,
            "authenticated": 2,
            "priority_granted": 3,
            "expired": 3,
        }
        current_step = status_to_step.get(self.session["status"], 0)
        step_details = [
            ("Tag detect", f"{self.session['tag_uid']} discovered by roadside reader"),
            ("Challenge", f"Nonce {self.session['challenge']} issued by {self.session['reader_id']}"),
            ("Auth", f"Response {self.session['response']} verified against trusted registry"),
            ("Grant", f"{self.session['lane']} reserved for {self.session['vehicle_id']}"),
        ]

        steps = []
        for index, (label, detail) in enumerate(step_details):
            if self.session["status"] == "expired" and index == len(step_details) - 1:
                state = "expired"
            elif index < current_step:
                state = "complete"
            elif index == current_step:
                state = "current"
            else:
                state = "pending"
            steps.append({"label": label, "state": state, "detail": detail})

        return {
            "vehicle_id": self.session["vehicle_id"],
            "authenticated": self.session["status"] in {"authenticated", "priority_granted"},
            "type": f"Emergency ({self.session['vehicle_type']})",
            "last_active": self.session["last_active"],
            "handshake_status": self.session["status"],
            "challenge": self.session["challenge"],
            "response_preview": self.session["response"],
            "lane": self.session["lane"],
            "reader_id": self.session["reader_id"],
            "tag_uid": self.session["tag_uid"],
            "session_age_s": round(now - self.session["started_at"], 1),
            "steps": steps,
            "audit_log": self.session["audit"],
        }
