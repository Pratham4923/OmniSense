import os
import threading
import time
from datetime import datetime, timedelta

from flask import Flask, jsonify, render_template, request, send_from_directory

from utils.mock_data import (
    BASE_DIR,
    get_acoustic_data,
    get_green_wave_path,
    get_route_definition,
    get_route_options,
    get_system_history,
    get_traffic_metrics,
    get_vision_data,
)
from utils.rfid_handshake import RFIDHandshakeManager


app = Flask(__name__)
RFID = RFIDHandshakeManager()

SIGNAL_SEQUENCE = [
    ("RED", 9),
    ("GREEN", 8),
    ("YELLOW", 3),
]
DEFAULT_VEHICLE = "Ambulance"
DEFAULT_ROUTE_ID = get_route_definition(vehicle_type=DEFAULT_VEHICLE)["id"]


def get_standby_route(route_id=None, vehicle_type=DEFAULT_VEHICLE):
    route = get_route_definition(route_id=route_id, vehicle_type=vehicle_type)
    return {
        "vehicle_type": vehicle_type,
        "route_id": route["id"],
        "route_name": route["name"],
        "corridor": route["corridor"],
        "junctions": get_green_wave_path(route_id=route["id"], vehicle_type=vehicle_type),
    }


def get_active_route():
    return RFID.get_active_route() or get_standby_route(
        route_id=STATE.get("selectedRouteId", DEFAULT_ROUTE_ID),
        vehicle_type=STATE.get("selectedVehicleType", DEFAULT_VEHICLE),
    )


def clamp_junction_index(junctions):
    STATE["junctionIndex"] = min(max(STATE["junctionIndex"], 0), len(junctions) - 1)
    STATE["activeSector"] = junctions[STATE["junctionIndex"]]["id"]


def default_state(now=None, selected_route_id=DEFAULT_ROUTE_ID):
    now = now or time.time()
    route_context = get_standby_route(route_id=selected_route_id, vehicle_type=DEFAULT_VEHICLE)
    junctions = route_context["junctions"]
    return {
        "simRunning": False,
        "signalState": "RED",
        "phaseIndex": 0,
        "phaseStartedAt": now,
        "countdown": SIGNAL_SEQUENCE[0][1],
        "junctionIndex": 0,
        "activeSector": junctions[0]["id"],
        "preemptUntil": 0.0,
        "emergencyType": None,
        "selectedVehicleType": DEFAULT_VEHICLE,
        "selectedRouteId": route_context["route_id"],
    }


STATE = default_state()
STATE_LOCK = threading.Lock()


def ist_time():
    return (datetime.utcnow() + timedelta(hours=5, minutes=30)).strftime("%H:%M:%S IST")


def normalize_media_path(path):
    if not path or not os.path.exists(path):
        return None
    relative_path = os.path.relpath(path, BASE_DIR)
    return f"/media/{relative_path.replace(os.sep, '/')}"


def advance_rfid_handshake(now):
    event = RFID.advance(now)
    if not event:
        return

    route_context = RFID.get_active_route()
    junctions = route_context["junctions"] if route_context else get_active_route()["junctions"]
    reader_index = min(event["current_reader_index"], len(junctions) - 1)

    if event["priority_granted"] or event["reader_advanced"]:
        STATE["simRunning"] = True
        STATE["emergencyType"] = event["vehicle_type"]
        STATE["junctionIndex"] = reader_index
        STATE["activeSector"] = junctions[reader_index]["id"]

    if event["priority_granted"]:
        STATE["preemptUntil"] = max(STATE["preemptUntil"], event["expires_at"])

    if event["priority_expired"] and event["route_complete"]:
        STATE["preemptUntil"] = 0.0


def advance_state(now):
    advance_rfid_handshake(now)

    route_context = get_active_route()
    junctions = route_context["junctions"]
    clamp_junction_index(junctions)

    if not STATE["simRunning"]:
        return

    is_preempted = STATE["preemptUntil"] > now
    if is_preempted:
        STATE["signalState"] = "GREEN"
        STATE["countdown"] = max(1, int(STATE["preemptUntil"] - now))
        STATE["activeSector"] = junctions[STATE["junctionIndex"]]["id"]
        return

    phase_name, phase_duration = SIGNAL_SEQUENCE[STATE["phaseIndex"]]
    elapsed = now - STATE["phaseStartedAt"]
    if elapsed >= phase_duration:
        STATE["phaseIndex"] = (STATE["phaseIndex"] + 1) % len(SIGNAL_SEQUENCE)
        STATE["phaseStartedAt"] = now
        phase_name, phase_duration = SIGNAL_SEQUENCE[STATE["phaseIndex"]]

        if STATE["phaseIndex"] == 0:
            STATE["junctionIndex"] = (STATE["junctionIndex"] + 1) % len(junctions)

    STATE["signalState"] = phase_name
    phase_remaining = phase_duration - int(now - STATE["phaseStartedAt"])
    STATE["countdown"] = max(1, phase_remaining)
    STATE["activeSector"] = junctions[STATE["junctionIndex"]]["id"]


def compose_payload():
    now = time.time()
    with STATE_LOCK:
        advance_state(now)
        route_context = get_active_route()
        sim_running = STATE["simRunning"]
        countdown = STATE["countdown"]
        junction_index = STATE["junctionIndex"]
        signal_state = STATE["signalState"]
        preempt_until = STATE["preemptUntil"]
        emergency_type = STATE["emergencyType"] or RFID.requested_vehicle_type
        active_sector = STATE["activeSector"]
        selected_route_id = STATE["selectedRouteId"]
        rfid = RFID.build_payload(now)

    sensor_target = emergency_type if sim_running or RFID.requested_vehicle_type else None
    acoustic = get_acoustic_data(sensor_target)
    vision = get_vision_data(sensor_target)
    junctions = route_context["junctions"]
    metrics = get_traffic_metrics()
    history = get_system_history()
    is_preempted = bool(preempt_until and preempt_until > now)
    priority_signals = [
        entry["junction_id"]
        for entry in rfid.get("route_progress", [])
        if entry["state"] in {"live", "reserved"}
    ]
    armed_signals = [
        entry["junction_id"]
        for entry in rfid.get("route_progress", [])
        if entry["state"] in {"tracking", "queued"}
    ]

    acoustic["audioUrl"] = normalize_media_path(acoustic.get("audio_path"))
    vision["imageUrl"] = normalize_media_path(vision.get("image_path"))

    return {
        "clock": ist_time(),
        "simRunning": sim_running,
        "countdown": countdown,
        "signalState": signal_state,
        "activeSector": active_sector,
        "emergencyType": emergency_type,
        "junctionIndex": junction_index,
        "junctions": junctions,
        "metrics": metrics,
        "history": history,
        "rfid": rfid,
        "acoustic": acoustic,
        "vision": vision,
        "isPreempted": is_preempted,
        "prioritySignals": priority_signals,
        "armedSignals": armed_signals,
        "selectedRouteId": selected_route_id,
        "routeOptions": get_route_options(DEFAULT_VEHICLE),
        "activeRoute": route_context,
    }


@app.route("/")
def index():
    return render_template("index.html", initial_state=compose_payload())


@app.route("/api/state")
def api_state():
    return jsonify(compose_payload())


@app.route("/api/action", methods=["POST"])
def api_action():
    payload = request.get_json(silent=True) or {}
    action = payload.get("action")

    with STATE_LOCK:
        now = time.time()
        advance_state(now)

        if action == "toggle":
            STATE["simRunning"] = not STATE["simRunning"]
            if STATE["simRunning"]:
                STATE["phaseStartedAt"] = now
            else:
                STATE["preemptUntil"] = 0.0

        elif action == "select_route":
            route_id = payload.get("routeId", DEFAULT_ROUTE_ID)
            route_context = get_standby_route(route_id=route_id, vehicle_type=DEFAULT_VEHICLE)
            STATE["selectedVehicleType"] = DEFAULT_VEHICLE
            STATE["selectedRouteId"] = route_context["route_id"]
            if not RFID.session:
                STATE["junctionIndex"] = 0
                STATE["activeSector"] = route_context["junctions"][0]["id"]
                STATE["countdown"] = SIGNAL_SEQUENCE[0][1]

        elif action == "inject":
            vehicle_type = payload.get("vehicleType", "Ambulance")
            route_id = payload.get("routeId") if vehicle_type == DEFAULT_VEHICLE else None
            route_context = get_standby_route(route_id=route_id, vehicle_type=vehicle_type)
            if vehicle_type == DEFAULT_VEHICLE:
                STATE["selectedVehicleType"] = DEFAULT_VEHICLE
                STATE["selectedRouteId"] = route_context["route_id"]

            RFID.start(vehicle_type, now, route_id=route_context["route_id"])
            active_route = RFID.get_active_route() or route_context
            STATE["simRunning"] = True
            STATE["emergencyType"] = vehicle_type
            STATE["phaseStartedAt"] = now
            STATE["phaseIndex"] = 0
            STATE["signalState"] = "RED"
            STATE["junctionIndex"] = 0
            STATE["activeSector"] = active_route["junctions"][0]["id"]

        elif action == "reset":
            selected_route_id = STATE.get("selectedRouteId", DEFAULT_ROUTE_ID)
            RFID.reset()
            STATE.clear()
            STATE.update(default_state(now, selected_route_id=selected_route_id))

    return jsonify(compose_payload())


@app.route("/media/<path:relative_path>")
def media(relative_path):
    return send_from_directory(BASE_DIR, relative_path)


if __name__ == "__main__":
    app.run(debug=True)
