import hashlib
import secrets
from copy import deepcopy
from datetime import datetime

from utils.mock_data import get_green_wave_path, get_route_definition


RFID_HANDSHAKE_TIMINGS = {
    "tag_detected": 0.8,
    "challenge_issued": 1.6,
    "authenticated": 2.4,
    "priority_granted": 3.0,
}
PREEMPT_LOOKAHEAD_SIGNALS = 2


def build_corridor(route_profile):
    corridor = []
    for index, node in enumerate(route_profile["junctions"], start=1):
        corridor.append(
            {
                "junction_id": node["id"],
                "junction_name": node["name"],
                "signal_id": node["signal_id"],
                "reader_id": f"{route_profile['reader_prefix']}-{index:02d}",
                "lane": node["lane"],
                "hold_seconds": node["hold_seconds"],
            }
        )
    return corridor


RFID_REGISTRY = {
    "Ambulance": {
        "vehicle_id": "EMRG-AMB-911",
        "tag_uid": "TAG-7A91-C2",
        "secret": "omnisense-ambulance-priority",
    },
    "Firetruck": {
        "vehicle_id": "EMRG-FIR-112",
        "tag_uid": "TAG-4F23-A8",
        "secret": "omnisense-firetruck-priority",
    },
}


def event_time(now=None):
    timestamp = datetime.fromtimestamp(now)
    return timestamp.strftime("%H:%M:%S")


def expected_response(secret, challenge):
    digest = hashlib.sha256(f"{secret}:{challenge}".encode("utf-8")).hexdigest().upper()
    return digest[:12]


class RFIDHandshakeManager:
    def __init__(self):
        self.requested_vehicle_type = None
        self.session = None

    def reset(self):
        self.requested_vehicle_type = None
        self.session = None

    def get_active_route(self):
        if not self.session:
            return None
        return {
            "vehicle_type": self.session["vehicle_type"],
            "route_id": self.session["route_id"],
            "route_name": self.session["route_name"],
            "corridor": self.session["corridor_name"],
            "junctions": deepcopy(self.session["route_map"]),
        }

    def start(self, vehicle_type, now, route_id=None):
        profile = RFID_REGISTRY[vehicle_type]
        route_profile = get_route_definition(route_id=route_id, vehicle_type=vehicle_type)
        route_map = get_green_wave_path(route_id=route_profile["id"], vehicle_type=vehicle_type)
        self.requested_vehicle_type = vehicle_type
        self.session = {
            "vehicle_type": vehicle_type,
            "vehicle_id": profile["vehicle_id"],
            "tag_uid": profile["tag_uid"],
            "secret": profile["secret"],
            "route_id": route_profile["id"],
            "route_name": route_profile["name"],
            "corridor_name": route_profile["corridor"],
            "route_map": route_map,
            "route": build_corridor(route_profile),
            "current_reader_index": 0,
            "status": "idle",
            "started_at": now,
            "reader_started_at": now,
            "last_transition_at": now,
            "expires_at": 0.0,
            "last_active": event_time(now),
            "challenge": None,
            "response": None,
            "audit": [],
        }
        self._enter_reader(0, now, initial=True)

    def _current_node(self):
        if not self.session:
            return None
        route = self.session["route"]
        index = self.session["current_reader_index"]
        return route[index]

    def _enter_reader(self, reader_index, now, initial=False):
        self.session["current_reader_index"] = reader_index
        self.session["status"] = "tag_detected"
        self.session["reader_started_at"] = now
        self.session["last_transition_at"] = now
        self.session["expires_at"] = 0.0
        self.session["challenge"] = secrets.token_hex(4).upper()
        self.session["response"] = expected_response(self.session["secret"], self.session["challenge"])

        node = self._current_node()
        if initial:
            title = "Route-locked tag detected"
            detail = (
                f"{self.session['tag_uid']} entered {node['reader_id']} for {self.session['route_name']}; "
                "off-route readers stay blocked"
            )
        else:
            title = "Corridor handoff"
            detail = f"Vehicle advanced to {node['reader_id']} at {node['junction_name']}"

        self.add_audit_entry(now, title, detail)

    def add_audit_entry(self, now, title, detail):
        if not self.session:
            return

        audit = self.session.setdefault("audit", [])
        audit.insert(
            0,
            {
                "time": event_time(now),
                "title": title,
                "detail": detail,
            },
        )
        del audit[8:]
        self.session["last_active"] = event_time(now)
        self.session["last_transition_at"] = now

    def advance(self, now):
        if not self.session:
            return None

        emitted = {
            "priority_granted": False,
            "priority_expired": False,
            "reader_advanced": False,
            "route_complete": False,
            "vehicle_type": self.session["vehicle_type"],
            "route_id": self.session["route_id"],
            "expires_at": 0.0,
            "current_reader_index": self.session["current_reader_index"],
        }

        while True:
            node = self._current_node()
            elapsed = now - self.session["reader_started_at"]
            current_status = self.session["status"]

            if current_status == "tag_detected" and elapsed >= RFID_HANDSHAKE_TIMINGS["tag_detected"]:
                self.session["status"] = "challenge_issued"
                self.add_audit_entry(
                    now,
                    "Reader challenge sent",
                    f"Nonce {self.session['challenge']} dispatched from {node['reader_id']} to {self.session['tag_uid']}",
                )
                continue

            if current_status == "challenge_issued" and elapsed >= RFID_HANDSHAKE_TIMINGS["challenge_issued"]:
                self.session["status"] = "authenticated"
                self.add_audit_entry(
                    now,
                    "Mutual auth passed",
                    f"Signed reply {self.session['response']} validated for {self.session['vehicle_id']}",
                )
                continue

            if current_status == "authenticated" and elapsed >= RFID_HANDSHAKE_TIMINGS["authenticated"]:
                self.session["status"] = "priority_granted"
                self.session["expires_at"] = now + node["hold_seconds"]
                emitted["priority_granted"] = True
                emitted["expires_at"] = self.session["expires_at"]
                emitted["current_reader_index"] = self.session["current_reader_index"]
                self.add_audit_entry(
                    now,
                    "Signal grant issued",
                    f"{node['lane']} opened at {node['signal_id']} for {self.session['vehicle_id']}",
                )
                continue

            if current_status == "priority_granted" and self.session["expires_at"] and now >= self.session["expires_at"]:
                if self.session["current_reader_index"] < len(self.session["route"]) - 1:
                    next_index = self.session["current_reader_index"] + 1
                    emitted["reader_advanced"] = True
                    emitted["current_reader_index"] = next_index
                    self._enter_reader(next_index, now)
                    continue

                self.session["status"] = "expired"
                emitted["priority_expired"] = True
                emitted["route_complete"] = True
                self.add_audit_entry(
                    now,
                    "Route completed",
                    f"{self.session['vehicle_id']} cleared the final junction on {self.session['route_name']}",
                )
                continue

            if current_status == "expired" and now - self.session["last_transition_at"] >= 6:
                self.reset()

            break

        return emitted

    def _build_steps(self):
        if not self.session:
            return [
                {"label": "Tag detect", "state": "current", "detail": "Waiting for an RFID beacon"},
                {"label": "Challenge", "state": "pending", "detail": "Reader nonce not issued"},
                {"label": "Auth", "state": "pending", "detail": "Cryptographic check idle"},
                {"label": "Grant", "state": "pending", "detail": "Signal corridor closed"},
            ]

        node = self._current_node()
        status_to_step = {
            "tag_detected": 0,
            "challenge_issued": 1,
            "authenticated": 2,
            "priority_granted": 3,
            "expired": 3,
        }
        current_step = status_to_step.get(self.session["status"], 0)
        step_details = [
            ("Tag detect", f"{self.session['tag_uid']} discovered by {node['reader_id']}"),
            ("Challenge", f"Nonce {self.session['challenge']} issued at {node['junction_name']}"),
            ("Auth", f"Response {self.session['response']} verified against the trusted registry"),
            ("Grant", f"{node['lane']} reserved on {node['signal_id']}"),
        ]

        steps = []
        for index, (label, detail) in enumerate(step_details):
            if self.session["status"] == "expired" and index == len(step_details) - 1:
                state = "expired"
            elif index < current_step:
                state = "complete"
            elif index == current_step:
                state = "current"
            else:
                state = "pending"
            steps.append({"label": label, "state": state, "detail": detail})
        return steps

    def _build_route_progress(self):
        if not self.session:
            standby_nodes = build_corridor(get_route_definition(vehicle_type="Ambulance"))
            return [
                {
                    "reader_id": node["reader_id"],
                    "junction_id": node["junction_id"],
                    "junction_name": node["junction_name"],
                    "signal_id": node["signal_id"],
                    "state": "pending",
                }
                for node in standby_nodes
            ]

        current_index = self.session["current_reader_index"]
        progress = []
        for index, node in enumerate(self.session["route"]):
            if self.session["status"] == "expired":
                state = "complete"
            elif index < current_index:
                state = "complete"
            elif index == current_index:
                state = "live" if self.session["status"] == "priority_granted" else "tracking"
            elif self.session["status"] in {"authenticated", "priority_granted"} and index <= current_index + PREEMPT_LOOKAHEAD_SIGNALS:
                state = "reserved"
            elif self.session["status"] == "challenge_issued" and index == current_index + 1:
                state = "queued"
            else:
                state = "pending"

            progress.append(
                {
                    "reader_id": node["reader_id"],
                    "junction_id": node["junction_id"],
                    "junction_name": node["junction_name"],
                    "signal_id": node["signal_id"],
                    "state": state,
                }
            )
        return progress

    def build_payload(self, now):
        if not self.session:
            standby_route = get_route_definition(vehicle_type="Ambulance")
            return {
                "vehicle_id": "NO-TAG",
                "authenticated": False,
                "type": "No emergency tag in range",
                "last_active": "N/A",
                "handshake_status": "idle",
                "challenge": None,
                "response_preview": None,
                "lane": "Standby corridor watch",
                "reader_id": "BLR-RDR-STANDBY",
                "reader_index": 0,
                "total_readers": len(standby_route["junctions"]),
                "signal_id": "SIG-STANDBY",
                "junction_id": "BLR-00",
                "junction_name": "Standby monitor",
                "route_id": standby_route["id"],
                "route_name": standby_route["name"],
                "corridor_name": standby_route["corridor"],
                "tag_uid": None,
                "session_age_s": 0.0,
                "steps": self._build_steps(),
                "route_progress": self._build_route_progress(),
                "active_signals": [],
                "reserved_signal_count": 0,
                "audit_log": [
                    {
                        "time": event_time(now),
                        "title": "Idle reader",
                        "detail": "No authenticated emergency vehicle in range",
                    }
                ],
            }

        node = self._current_node()
        route_progress = self._build_route_progress()
        active_signals = [
            entry["signal_id"]
            for entry in route_progress
            if entry["state"] in {"live", "reserved"}
        ]
        return {
            "vehicle_id": self.session["vehicle_id"],
            "authenticated": self.session["status"] in {"authenticated", "priority_granted"},
            "type": f"Emergency ({self.session['vehicle_type']})",
            "last_active": self.session["last_active"],
            "handshake_status": self.session["status"],
            "challenge": self.session["challenge"],
            "response_preview": self.session["response"],
            "lane": node["lane"],
            "reader_id": node["reader_id"],
            "reader_index": self.session["current_reader_index"],
            "total_readers": len(self.session["route"]),
            "signal_id": node["signal_id"],
            "junction_id": node["junction_id"],
            "junction_name": node["junction_name"],
            "route_id": self.session["route_id"],
            "route_name": self.session["route_name"],
            "corridor_name": self.session["corridor_name"],
            "tag_uid": self.session["tag_uid"],
            "session_age_s": round(now - self.session["started_at"], 1),
            "steps": self._build_steps(),
            "route_progress": route_progress,
            "active_signals": active_signals,
            "reserved_signal_count": len(active_signals),
            "audit_log": self.session["audit"],
        }
