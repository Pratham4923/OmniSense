import glob
import os
import random


# Paths to the datasets
BASE_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))
AMBULANCE_DIR = os.path.join(BASE_DIR, "Ambulance")
FIRETRUCK_DIR = os.path.join(BASE_DIR, "Firetrucks", "Firetrucks")


ROUTE_LIBRARY = {
    "Ambulance": [
        {
            "id": "amb-city-hospital",
            "name": "City Hospital Spine",
            "corridor": "South Bengaluru -> Richmond trauma center",
            "reader_prefix": "BLR-RDR-AMB-A",
            "junctions": [
                {
                    "id": "BLR-01",
                    "name": "Silk Board Junction",
                    "coords": [12.9177, 77.6238],
                    "signal_id": "SIG-01",
                    "lane": "Silk Board emergency lane",
                    "hold_seconds": 12,
                },
                {
                    "id": "BLR-02",
                    "name": "Madiwala Check Post",
                    "coords": [12.9266, 77.6204],
                    "signal_id": "SIG-02",
                    "lane": "Madiwala relief lane",
                    "hold_seconds": 10,
                },
                {
                    "id": "BLR-03",
                    "name": "Adugodi Signal",
                    "coords": [12.9416, 77.6145],
                    "signal_id": "SIG-03",
                    "lane": "Adugodi rapid passage",
                    "hold_seconds": 12,
                },
                {
                    "id": "BLR-04",
                    "name": "Shantinagar Junction",
                    "coords": [12.9567, 77.5937],
                    "signal_id": "SIG-04",
                    "lane": "Shantinagar hospital spine",
                    "hold_seconds": 10,
                },
                {
                    "id": "BLR-05",
                    "name": "Richmond Circle",
                    "coords": [12.9666, 77.5997],
                    "signal_id": "SIG-05",
                    "lane": "Richmond final approach",
                    "hold_seconds": 12,
                },
            ],
        },
        {
            "id": "amb-st-johns",
            "name": "St. John's Critical Care",
            "corridor": "Silk Board -> Koramangala trauma corridor",
            "reader_prefix": "BLR-RDR-AMB-B",
            "junctions": [
                {
                    "id": "BLR-11",
                    "name": "Silk Board Flyover",
                    "coords": [12.9162, 77.6245],
                    "signal_id": "SIG-11",
                    "lane": "Silk Board trauma lane",
                    "hold_seconds": 12,
                },
                {
                    "id": "BLR-12",
                    "name": "BTM Layout 2nd Stage",
                    "coords": [12.9169, 77.6102],
                    "signal_id": "SIG-12",
                    "lane": "BTM rapid care lane",
                    "hold_seconds": 10,
                },
                {
                    "id": "BLR-13",
                    "name": "Forum South Gate",
                    "coords": [12.9352, 77.6101],
                    "signal_id": "SIG-13",
                    "lane": "Forum bypass pocket",
                    "hold_seconds": 12,
                },
                {
                    "id": "BLR-14",
                    "name": "Sony World Junction",
                    "coords": [12.9344, 77.6248],
                    "signal_id": "SIG-14",
                    "lane": "Koramangala medical corridor",
                    "hold_seconds": 10,
                },
                {
                    "id": "BLR-15",
                    "name": "St. John's Hospital Gate",
                    "coords": [12.9342, 77.6209],
                    "signal_id": "SIG-15",
                    "lane": "Hospital intake lane",
                    "hold_seconds": 14,
                },
            ],
        },
        {
            "id": "amb-manipal-east",
            "name": "East Command Run",
            "corridor": "Domlur -> Old Airport Road emergency run",
            "reader_prefix": "BLR-RDR-AMB-C",
            "junctions": [
                {
                    "id": "BLR-21",
                    "name": "Madiwala Link Ramp",
                    "coords": [12.9295, 77.6206],
                    "signal_id": "SIG-21",
                    "lane": "Madiwala dispatch lane",
                    "hold_seconds": 11,
                },
                {
                    "id": "BLR-22",
                    "name": "Domlur Flyover Base",
                    "coords": [12.9602, 77.6387],
                    "signal_id": "SIG-22",
                    "lane": "Domlur priority chute",
                    "hold_seconds": 10,
                },
                {
                    "id": "BLR-23",
                    "name": "100 Feet Road East",
                    "coords": [12.9685, 77.6409],
                    "signal_id": "SIG-23",
                    "lane": "Indiranagar response lane",
                    "hold_seconds": 12,
                },
                {
                    "id": "BLR-24",
                    "name": "HAL Main Gate",
                    "coords": [12.9588, 77.6524],
                    "signal_id": "SIG-24",
                    "lane": "HAL med-evac lane",
                    "hold_seconds": 10,
                },
                {
                    "id": "BLR-25",
                    "name": "Manipal Hospital Approach",
                    "coords": [12.9597, 77.6498],
                    "signal_id": "SIG-25",
                    "lane": "Old Airport final approach",
                    "hold_seconds": 14,
                },
            ],
        },
    ],
    "Firetruck": [
        {
            "id": "fir-cbd-response",
            "name": "CBD Response Arc",
            "corridor": "South Bengaluru -> central business district",
            "reader_prefix": "BLR-RDR-FIR-A",
            "junctions": [
                {
                    "id": "BLR-01",
                    "name": "Silk Board Junction",
                    "coords": [12.9177, 77.6238],
                    "signal_id": "SIG-01",
                    "lane": "Silk Board response lane",
                    "hold_seconds": 12,
                },
                {
                    "id": "BLR-02",
                    "name": "Madiwala Check Post",
                    "coords": [12.9266, 77.6204],
                    "signal_id": "SIG-02",
                    "lane": "Madiwala hazmat lane",
                    "hold_seconds": 10,
                },
                {
                    "id": "BLR-03",
                    "name": "Adugodi Signal",
                    "coords": [12.9416, 77.6145],
                    "signal_id": "SIG-03",
                    "lane": "Adugodi fire corridor",
                    "hold_seconds": 12,
                },
                {
                    "id": "BLR-04",
                    "name": "Shantinagar Junction",
                    "coords": [12.9567, 77.5937],
                    "signal_id": "SIG-04",
                    "lane": "Shantinagar command lane",
                    "hold_seconds": 10,
                },
                {
                    "id": "BLR-05",
                    "name": "Richmond Circle",
                    "coords": [12.9666, 77.5997],
                    "signal_id": "SIG-05",
                    "lane": "Richmond staging approach",
                    "hold_seconds": 12,
                },
            ],
        }
    ],
}


def get_random_asset(category, sub_folder):
    """Picks a random file from the dataset folders."""
    if category == "Ambulance":
        search_path = os.path.join(AMBULANCE_DIR, sub_folder)
    else:
        search_path = os.path.join(FIRETRUCK_DIR, sub_folder)

    if not os.path.exists(search_path):
        search_path = os.path.join(
            AMBULANCE_DIR if category == "Ambulance" else FIRETRUCK_DIR,
            sub_folder.capitalize(),
        )

    if sub_folder in ("images", "Images"):
        test_path = os.path.join(search_path, "Test")
        if os.path.exists(test_path):
            search_path = test_path

    files = glob.glob(os.path.join(search_path, "*.*"))
    if not files:
        return None
    return random.choice(files)


def get_route_definition(route_id=None, vehicle_type="Ambulance"):
    routes = ROUTE_LIBRARY.get(vehicle_type) or ROUTE_LIBRARY["Ambulance"]
    if route_id:
        for route in routes:
            if route["id"] == route_id:
                return route
    return routes[0]


def get_route_options(vehicle_type="Ambulance"):
    return [
        {
            "id": route["id"],
            "name": route["name"],
            "corridor": route["corridor"],
            "vehicle_type": vehicle_type,
            "node_count": len(route["junctions"]),
        }
        for route in ROUTE_LIBRARY.get(vehicle_type, [])
    ]


def get_rfid_data(emergency_type=None):
    if emergency_type:
        return {
            "vehicle_id": f"EMRG-{emergency_type[:3].upper()}-911",
            "authenticated": True,
            "type": f"Emergency ({emergency_type})",
            "last_active": "LIVE",
        }
    return {
        "vehicle_id": f"PVT-{random.randint(1000, 9999)}",
        "authenticated": False,
        "type": "Private Vehicle",
        "last_active": "N/A",
    }


def get_acoustic_data(emergency_type=None):
    if emergency_type:
        sound_file = get_random_asset(emergency_type, "sounds")
        return {
            "confidence": random.uniform(0.92, 0.99),
            "siren_detected": True,
            "label": f"{emergency_type} Siren",
            "audio_path": sound_file,
            "decibel": random.uniform(85, 110),
        }
    return {
        "confidence": random.uniform(0.05, 0.2),
        "siren_detected": False,
        "label": "Ambient Noise",
        "audio_path": None,
        "decibel": random.uniform(40, 60),
    }


def get_vision_data(emergency_type=None):
    if emergency_type:
        image_file = get_random_asset(emergency_type, "images")
        return {
            "detected": True,
            "confidence": random.uniform(0.9, 0.98),
            "distance_m": random.uniform(15.0, 40.0),
            "label": emergency_type,
            "image_path": image_file,
            "frame_rate": random.uniform(28, 32),
        }
    return {
        "detected": False,
        "confidence": random.uniform(0.1, 0.25),
        "distance_m": random.uniform(50.0, 150.0),
        "label": "Road Normal",
        "image_path": None,
        "frame_rate": 30.0,
    }


def get_green_wave_path(route_id=None, vehicle_type="Ambulance"):
    """Returns the current route junctions for the selected emergency corridor."""
    route = get_route_definition(route_id=route_id, vehicle_type=vehicle_type)
    return [
        {
            "id": junction["id"],
            "name": junction["name"],
            "coords": junction["coords"],
        }
        for junction in route["junctions"]
    ]


def get_system_history():
    """Simulates preemption history for charts."""
    return [random.randint(0, 1) for _ in range(20)]


def get_traffic_metrics():
    return {
        "eta_reduction": random.uniform(38, 45),
        "detection_accuracy": random.uniform(99.1, 99.9),
        "false_trigger_rate": random.uniform(0.005, 0.02),
        "latency_ms": random.uniform(85, 110),
    }
